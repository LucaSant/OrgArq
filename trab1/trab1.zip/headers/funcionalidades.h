/*
    SCC0215 - Organização de Arquivos (2022.1)
    Antônio Medrado - 10748389
    Lucas Sant'Anna - 10748521
*/

int csv_to_bin(char *tipoArquivo, char *arquivoEntrada); // Funcionalidade [1]
int read_all(char *tipoArquivo, char *arquivoEntrada); // Funcionalidade [2]
int read_filter(char *tipoArquivo, char *arquivoEntrada); // Funcionalidade [3]
int read_rrn(char *tipoArquivo, char *arquivoEntrada); // Funcionalidade [4]