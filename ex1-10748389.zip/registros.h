// Antônio Medrado 10748389

#include <stdio.h>

void imprimeRegistro(FILE *f);
int gravar(char filename[31]);
int recuperar(char filename[31]);
int recuperarRegistro(char filename[31]);

void readline(char* string);
void binarioNaTela(char *nomeArquivoBinario);